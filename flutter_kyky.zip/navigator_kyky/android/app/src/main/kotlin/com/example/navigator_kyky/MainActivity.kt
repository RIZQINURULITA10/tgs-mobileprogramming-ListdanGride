package com.example.navigator_kyky

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
