import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Katalog Produk',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

// Model Produk
class Product {
  final String name;
  final String description;
  final double price;
  final String imageUrl;

  Product({
    required this.name,
    required this.description,
    required this.price,
    required this.imageUrl,
  });
}

// Data Dummy Produk dengan Link Gambar Baru
List<Product> products = [
  Product(
    name: 'Laptop Gaming',
    description: 'Laptop dengan performa tinggi untuk gaming.',
    price: 15000000,
    imageUrl:
        'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=300&h=200&fit=crop', // Gambar laptop gaming
  ),
  Product(
    name: 'Smartphone Android',
    description: 'Smartphone terbaru dengan kamera canggih.',
    price: 5000000,
    imageUrl:
        'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop', // Gambar smartphone
  ),
  Product(
    name: 'Headphone Wireless',
    description: 'Headphone nirkabel dengan suara berkualitas.',
    price: 800000,
    imageUrl:
        'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=200&fit=crop', // Gambar headphone
  ),
  Product(
    name: 'Mouse Gaming',
    description: 'Mouse ergonomis untuk gamer.',
    price: 300000,
    imageUrl:
        'https://images.unsplash.com/photo-1527814050087-3793815479db?w=300&h=200&fit=crop', // Gambar mouse
  ),
  Product(
    name: 'Keyboard Mekanik',
    description: 'Keyboard dengan switch mekanik.',
    price: 600000,
    imageUrl:
        'https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=300&h=200&fit=crop', // Gambar keyboard
  ),
  Product(
    name: 'Monitor 4K',
    description: 'Monitor resolusi tinggi untuk produktivitas.',
    price: 4000000,
    imageUrl:
        'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=300&h=200&fit=crop', // Gambar monitor
  ),
];

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Katalog Produk'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Daftar Produk'),
              Tab(text: 'Grid Produk'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Tab 1: ListView untuk ringkasan produk
            ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return Card(
                  margin: EdgeInsets.all(8.0),
                  child: ListTile(
                    leading: Image.network(
                      product.imageUrl,
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                    title: Text(product.name),
                    subtitle: Text(
                      '${product.description}\nHarga: Rp ${product.price.toStringAsFixed(0)}',
                    ),
                    isThreeLine: true,
                  ),
                );
              },
            ),
            // Tab 2: GridView untuk foto produk
            GridView.builder(
              padding: EdgeInsets.all(8.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // Jumlah kolom
                crossAxisSpacing: 8.0,
                mainAxisSpacing: 8.0,
                childAspectRatio: 0.75, // Rasio aspek untuk gambar
              ),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return Card(
                  child: Column(
                    children: [
                      Expanded(
                        child: Image.network(
                          product.imageUrl,
                          fit: BoxFit.cover,
                          width: double.infinity,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          product.name,
                          style: TextStyle(fontWeight: FontWeight.bold),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
